class LeaderboardModel {
  // token
  // image
  // name
  // birthday
  // description
  final String id;
  final String description;
  final String name;
  final String birthday;
  final String rating;
  final String totalVotes;
  final String imageUrl;
  final String externalUrl;

  LeaderboardModel({
    required this.id,
    required this.description,
    required this.externalUrl,
    required this.name,
    required this.birthday,
    required this.rating,
    required this.totalVotes,
    required this.imageUrl,
  });

  LeaderboardModel copyWith({
    String? id,
    String? name,
    String? birthday,
    String? externalUrl,
    String? rating,
    String? imageUrl,
    String? totalVotes,
    String? description,
  }) {
    return LeaderboardModel(
      id: id ?? this.id,
      name: name ?? this.name,
      birthday: birthday ?? this.birthday,
      description: description ?? this.description,
      externalUrl: externalUrl ?? this.externalUrl,
      rating: rating ?? this.rating,
      totalVotes: totalVotes ?? this.totalVotes,
      imageUrl: imageUrl ?? this.imageUrl,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'name': name,
      'birthday': birthday,
      'rating': rating,
      'total_votes': totalVotes,
      'image_url': imageUrl,
      'external_url': externalUrl,
      'description': description,
    };
  }

  factory LeaderboardModel.fromMap(Map<String, dynamic> map) {
    return LeaderboardModel(
      id: map['id'] ?? '',
      name: map['name'] ?? '',
      totalVotes: map['total_votes'] ?? '',
      birthday: map['birthday'] ?? '',
      rating: map['rating'] ?? 0,
      imageUrl: map['image_url'] ?? '',
      description: map['description'] ?? '',
      externalUrl: map['external_url'] ?? '',
    );
  }

  factory LeaderboardModel.fromJson(dynamic map) {
    return LeaderboardModel(
      id: map['id'] ?? '',
      name: map['name'] ?? '',
      totalVotes: map['total_votes'] ?? '',
      birthday: map['birthday'] ?? '',
      rating: map['rating'] ?? 0,
      imageUrl: map['image_url'] ?? '',
      description: map['description'] ?? '',
      externalUrl: map['external_url'] ?? '',
    );
  }
}
