class PetModel {
  // token
  // image
  // name
  // birthday
  // description
  final String id;
  final String name;
  final String birthdate;
  final String rating;
  final String votes;
  final String url;

  PetModel({
    required this.id,
    required this.name,
    required this.birthdate,
    required this.rating,
    required this.votes,
    required this.url,
  });

  PetModel copyWith({
    String? id,
    String? name,
    String? birthdate,
    String? rating,
    String? votes,
    String? url,
  }) {
    return PetModel(
      id: id ?? this.id,
      name: name ?? this.name,
      birthdate: birthdate ?? this.birthdate,
      rating: rating ?? this.rating,
      votes: votes ?? this.votes,
      url: url ?? this.url,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'name': name,
      'birthdate': birthdate,
      'rating': rating,
      'votes': votes,
      'url': url,
    };
  }

  factory PetModel.fromMap(Map<String, dynamic> map) {
    return PetModel(
      id: map['id'] ?? '',
      name: map['name'] ?? '',
      votes: map['votes'] ?? '',
      birthdate: map['birthdate'] ?? '',
      rating: map['rating'] ?? '',
      url: map['url'] ?? '',
    );
  }

  factory PetModel.fromJson(dynamic map) {
    return PetModel(
      id: map['id'] ?? '',
      name: map['name'] ?? '',
      votes: map['votes'] ?? '',
      birthdate: map['birthdate'] ?? '',
      rating: map['rating'] ?? '',
      url: map['url'] ?? '',
    );
  }
}
