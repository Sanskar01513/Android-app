import 'dart:convert';
import 'dart:io';
import 'package:http/http.dart' as http;
import 'package:ugly_pets/models/pet_model.dart';

class API {

  Future<bool> ratePet(String token, String petId, double rating) async {
    final response = await http.post(Uri.parse('https://www.jwuclasses.com/ugly/savevote?token=$token&pet_id=$petId&rating=$rating'));
    print(response.body);
    if(response.statusCode == 200) {
      return true;
    }
    return false;
  }

  logout(String token) async {
    final response = await http.post(Uri.parse('https://www.jwuclasses.com/ugly/logout?token=$token'));
    print(response.body);
    if(response.statusCode == 200) {
      Map<String, dynamic> data = json.decode(response.body);
      if(data['success'] == 1) {
        return true;
      } else {
        return false;
      }
    } else {
      return false;
    }
  }

  Future<List<PetModel>> getPetsToVote() async {
    final response =
        await http.get(Uri.parse('https://www.jwuclasses.com/ugly/getvote'));
    List<PetModel> result = [];
    if (response.statusCode == 200) {
      // If the server did return a 200 OK response,
      // then parse the JSON.
      Map<String, dynamic> data = json.decode(response.body);
      if (data['success'] == 1) {
        result.add(
          PetModel(
            id: data['pet']['id'] ?? '',
            name: data['pet']['name'] ?? '',
            birthdate: data['pet']['birthdate'] ?? '',
            rating: data['pet']['rating'] ?? '',
            votes: data['pet']['votes'] ?? '',
            url: data['pet']['url'] ?? '',
          ),
        );
      }
    } else {
      // If the server did not return a 200 OK response,
      // then throw an exception.
      throw Exception('Failed to load data');
    }
    return result;
  }

  void deletePet(String token, String petId) async {
    final response = await http.post(Uri.parse(
        'https://www.jwuclasses.com/ugly/pets/delete?token=$token&id=$petId'));
    print(response.body);
  }

  void addPet(
      {required String token,
      required String name,
      required String birthday,
      required String description,
      required File image}) async {
    print('adding pet');
    List<int> imageBytes = image.readAsBytesSync();
    String baseImage = base64Encode(imageBytes);

    final response = await http.post(Uri.parse(
        'https://www.jwuclasses.com/ugly/pets/add?token=$token&name=$name&image=$baseImage&birthday=$birthday&description=$description'));
    print('pet added');
  }

  Future<List<PetModel>> getLeaderboardPets() async {
    final response = await http
        .get(Uri.parse('https://www.jwuclasses.com/ugly/leaderboard'));
    List<PetModel> result = [];

    if (response.statusCode == 200) {
      // If the server did return a 200 OK response,
      // then parse the JSON.
      Map<String, dynamic> data = json.decode(response.body);
      if (data['success'] == 1) {
        String jsonString = jsonEncode(data['pets']);
        var petDataMaps = jsonDecode(jsonString);
        petDataMaps.forEach((data) {
          result.add(PetModel.fromJson(data));
        });
      }
    } else {
      // If the server did not return a 200 OK response,
      // then throw an exception.
      throw Exception('Failed to load data');
    }
    return result;
  }

  Future<List<PetModel>> getPets(String token) async {
    final response = await http.get(
        Uri.parse('https://www.jwuclasses.com/ugly/pets/list?token=$token'));
    List<PetModel> result = [];
    if (response.statusCode == 200) {
      // If the server did return a 200 OK response,
      // then parse the JSON.
      Map<String, dynamic> data = json.decode(response.body);
      if (data['success'] == 1) {
        String jsonString = jsonEncode(data['pets']);
        var petDataMaps = jsonDecode(jsonString);
        petDataMaps.forEach((data) {
          result.add(PetModel.fromJson(data));
        });
      }
    } else {
      // If the server did not return a 200 OK response,
      // then throw an exception.
      throw Exception('Failed to load data');
    }
    return result;
  }

  Future<String?> login(String email, String password) async {
    final response = await http.get(Uri.parse(
        'https://www.jwuclasses.com/ugly/login?email=$email&password=$password'));

    if (response.statusCode == 200) {
      // If the server did return a 200 OK response,
      // then parse the JSON.
      Map<String, dynamic> data = json.decode(response.body);
      if (data['success'] == 1) {
        return data['token'];
      }
    } else {
      // If the server did not return a 200 OK response,
      // then throw an exception.
      throw Exception('Failed to load data');
    }
  }

  Future<String?> register(String email, String password) async {
    final response = await http.get(Uri.parse(
        'https://www.jwuclasses.com/ugly/register?email=$email&password=$password'));

    if (response.statusCode == 200) {
      // If the server did return a 200 OK response,
      // then parse the JSON.
      Map<String, dynamic> data = json.decode(response.body);
      if (data['success'] == 1) {
        return data['token'];
      }
    } else {
      // If the server did not return a 200 OK response,
      // then throw an exception.
      throw Exception('Failed to load data');
    }
  }
}
