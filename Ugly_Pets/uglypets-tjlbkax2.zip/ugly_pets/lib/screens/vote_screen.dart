import 'package:flutter/material.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:ugly_pets/api/API.dart';
import 'package:ugly_pets/widgets/custom_button.dart';

import '../models/pet_model.dart';

class VoteScreen extends StatefulWidget {
  final String token;

  const VoteScreen({Key? key, required this.token}) : super(key: key);

  @override
  State<VoteScreen> createState() => _VoteScreenState();
}

class _VoteScreenState extends State<VoteScreen> {
  List<PetModel> pets = [];
  double rating = 3;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    getVotePets();
  }

  void getVotePets() async {
    pets = await API().getPetsToVote();
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        elevation: 0,
        title: const Text('Vote a Pet'),
        centerTitle: true,
      ),
      body: Column(
        children: [
          showVoteList(),
        ],
      ),
    );
  }

  showVoteList() {
    return Column(
      children: [
        const SizedBox(height: 20),
        ListView.builder(
          itemCount: pets.length,
          shrinkWrap: true,
          itemBuilder: (context, index) {
            return Card(
              child: ListTile(
                leading: Container(
                  width: 80,
                  height: 80,
                  color: Colors.grey,
                ),
                title: Text(pets[index].name),
                subtitle: Text(''),
              ),
            );
          },
        ),
        const SizedBox(height: 20),
        RatingBar.builder(
          initialRating: rating,
          minRating: 1,
          maxRating: 5,
          direction: Axis.horizontal,
          allowHalfRating: false,
          itemCount: 5,
          itemPadding: const EdgeInsets.symmetric(horizontal: 4.0),
          itemBuilder: (context, _) =>
          const Icon(
            Icons.star,
            color: Colors.amber,
          ),
          onRatingUpdate: (value) {
            rating = value;
          },
        ),
        const SizedBox(height: 20),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 50,),
          child: CustomButton(onTap: () => ratePet(pets.first.id), text: 'Rate'),
        ),
      ],
    );
  }

  ratePet(String petId) async  {
    bool isRated = await API().ratePet(widget.token, petId, rating);
    if(isRated) {
      Navigator.pop(context);
    } else {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Please Try again later')));
    }
  }

}
