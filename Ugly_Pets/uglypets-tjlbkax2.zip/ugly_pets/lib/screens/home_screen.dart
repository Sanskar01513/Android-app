import 'dart:io';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:ugly_pets/api/API.dart';
import 'package:ugly_pets/screens/Leaderboard_screen.dart';
import 'package:ugly_pets/screens/login_screen.dart';
import 'package:ugly_pets/screens/vote_screen.dart';
import 'package:ugly_pets/widgets/custom_button.dart';
import 'package:ugly_pets/widgets/custom_textField.dart';
import 'package:ugly_pets/widgets/pet_card.dart';

import '../models/pet_model.dart';

class HomeScreen extends StatefulWidget {
  final String token;

  const HomeScreen({
    Key? key,
    required this.token,
  }) : super(key: key);

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  List<PetModel> pets = [];
  bool setInputState = false;
  PickedFile? uploadImage;
  final TextEditingController name = TextEditingController();
  final TextEditingController birthday = TextEditingController();
  final TextEditingController description = TextEditingController();
  final TextEditingController image = TextEditingController();

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    getPets(widget.token);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: SingleChildScrollView(
          child: Column(
            children: [
              const SizedBox(height: 20),
              Padding(
                padding:
                    const EdgeInsets.symmetric(vertical: 10, horizontal: 40),
                child: Row(
                  children: [
                    Flexible(
                      child: CustomButton(
                        onTap: () => setState(() {
                          setInputState = !setInputState;
                        }),
                        text: 'Add',
                      ),
                    ),
                    const SizedBox(
                      width: 20,
                    ),
                    Flexible(
                      child: CustomButton(
                        onTap: viewLeaderboard,
                        text: 'Leaderboard',
                      ),
                    ),
                  ],
                ),
              ),
              Padding(
                padding:
                    const EdgeInsets.symmetric(vertical: 10, horizontal: 40),
                child: Row(
                  children: [
                    Flexible(
                      child: CustomButton(
                        onTap: () => getPets(widget.token),
                        text: 'Refresh',
                      ),
                    ),
                    const SizedBox(
                      width: 20,
                    ),
                    Flexible(
                      child: CustomButton(
                        onTap: votePets,
                        text: 'Vote',
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 5),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 60),
                child: CustomButton(
                  onTap: logout,
                  text: 'Logout',
                ),
              ),
              const SizedBox(height: 10),
              if (setInputState)
                Column(
                  children: [
                    CustomTextField(
                      controller: name,
                      hintText: 'pet name: ',
                      icon: Icons.account_circle,
                      obscureText: false,
                      keyboardType: TextInputType.name,
                    ),
                    const SizedBox(height: 10),
                    CustomTextField(
                      controller: description,
                      hintText: 'Description: ',
                      icon: Icons.description,
                      obscureText: false,
                      keyboardType: TextInputType.multiline,
                    ),
                    const SizedBox(height: 10),
                    CustomTextField(
                      controller: birthday,
                      hintText: 'Birthday: ',
                      icon: Icons.cake_outlined,
                      obscureText: false,
                      keyboardType: TextInputType.datetime,
                    ),
                    const SizedBox(height: 10),
                    CustomButton(
                      onTap: getImage,
                      text: 'Choose Image',
                    ),
                    const SizedBox(height: 10),
                    Padding(
                      padding: const EdgeInsets.symmetric(
                          vertical: 10, horizontal: 50),
                      child: CustomButton(
                        onTap: addPet,
                        text: 'ADD',
                      ),
                    ),
                  ],
                ),
              ListView.builder(
                shrinkWrap: true,
                itemCount: pets.length,
                itemBuilder: (context, index) {
                  return PetCard(
                    pet: pets[index],
                    onPressed: () => deletePet(pets[index].id),
                  );
                },
              ),
            ],
          ),
        ),
      ),
    );
  }

  getImage() async {
    var choosedimage =
        await ImagePicker.platform.pickImage(source: ImageSource.gallery);
    setState(() {
      uploadImage = choosedimage;
    });
  }

  logout() async {
    bool success = await API().logout(widget.token);
    if (success) {
      Navigator.pushReplacement(context,
          MaterialPageRoute(builder: (context) => const LoginScreen()));
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Please try again later')));
    }
  }

  addPet() {
    API().addPet(
      token: widget.token,
      name: name.text.trim(),
      birthday: name.text.trim(),
      description: description.text.trim(),
      image: File(uploadImage!.path),
    );

    setState(() {
      setInputState = false;
      getPets(widget.token);
    });
  }

  viewLeaderboard() {
    Navigator.push(
        context,
        MaterialPageRoute(
            builder: (context) => LeaderboardScreen(
                  token: widget.token,
                )));
  }

  deletePet(String petId) {
    setState(() {
      API().deletePet(widget.token, petId);
      getPets(widget.token);
    });
  }

  getPets(String token) async {
    pets = await API().getPets(token);
    setState(() {});
  }

  votePets() {
    Navigator.push(
        context,
        MaterialPageRoute(
            builder: (context) => VoteScreen(token: widget.token)));
  }
}
