import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:ugly_pets/api/API.dart';
import 'package:ugly_pets/widgets/custom_button.dart';
import 'package:ugly_pets/widgets/custom_textField.dart';

class RegisterScreen extends StatefulWidget {
  const RegisterScreen({Key? key}) : super(key: key);

  @override
  State<RegisterScreen> createState() => _RegisterScreenState();
}

class _RegisterScreenState extends State<RegisterScreen> {
  final TextEditingController email = TextEditingController();
  final TextEditingController password = TextEditingController();


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        leading: IconButton(
          onPressed: () {
            Navigator.pop(context);
          },
          icon: const Icon(Icons.arrow_back_ios_new_outlined, color: Colors.black,),
        ),
        title: Text(
          'Register',
          style: GoogleFonts.manrope(
            fontSize: 18,
            color: Colors.black,
            fontWeight: FontWeight.w700,
          ),
        ),
        centerTitle: true,
      ),
      backgroundColor: Colors.white,
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 24),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 10),
              child: CustomTextField(
                controller: email,
                hintText: 'email: ',
                icon: Icons.supervisor_account,
                obscureText: false,
                keyboardType: TextInputType.text,
              ),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 10),
              child: CustomTextField(
                controller: password,
                hintText: 'password: ',
                keyboardType: TextInputType.text,
                obscureText: true,
                icon: Icons.lock_outline_rounded,
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(10.0),
              child: CustomButton(
                onTap: register,
                text: 'Register',
              ),
            )
          ],
        ),
      ),
    );
  }

  register() async {
    String? token = await API().register(email.text.trim(), password.text);
    if(token != null && token.isNotEmpty) {
      Navigator.pop(context);
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Register Successful')));
      print(token);
    }
  }

}
