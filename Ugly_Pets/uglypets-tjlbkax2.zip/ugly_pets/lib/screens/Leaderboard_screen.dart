import 'package:flutter/material.dart';
import 'package:ugly_pets/api/API.dart';
import 'package:ugly_pets/widgets/leaderboard_card.dart';
import 'package:url_launcher/url_launcher.dart';

import '../models/Leaderboard_model.dart';
import '../models/pet_model.dart';

class LeaderboardScreen extends StatefulWidget {
  final String token;
  const LeaderboardScreen({Key? key, required this.token}) : super(key: key);

  @override
  State<LeaderboardScreen> createState() => _LeaderboardScreenState();
}

class _LeaderboardScreenState extends State<LeaderboardScreen> {
  List<PetModel> leaderboardList = [];

  getLeaderboardPets() async {
    leaderboardList = await API().getLeaderboardPets();
    setState(() {

    });
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    getLeaderboardPets();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        elevation: 0,
        title: const Text('Leaderboard'),
        centerTitle: true,
      ),
      body: Column(
        children: [
          showLeaderboard(),
        ],
      ),
    );
  }

  showLeaderboard() {
    leaderboardList.sort((a, b) => b.votes.compareTo(a.votes));
    return Column(
      children: [
        ListView.builder(
          itemCount: leaderboardList.length,
          shrinkWrap: true,
          itemBuilder: (context, index) {
            return LeaderboardCard(pet: leaderboardList[index], onPressed: () async {
              await launchUrl(Uri.parse("mailto:email?subject=subject&body=body"));
            });
          },
        ),
      ],
    );
  }
}
