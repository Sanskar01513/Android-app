import 'package:flutter/material.dart';
import 'package:ugly_pets/models/pet_model.dart';

class PetCard extends StatelessWidget {
  final PetModel pet;
  final VoidCallback onPressed;
  const PetCard({Key? key, required this.pet, required this.onPressed}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Card(
      child: ListTile(
        // leading: Image.network(pet.url, width: 80, height: 80,),
        leading: Container(width: 80, height: 80, color: Colors.grey,),
        title: Text(pet.name),
        subtitle: Text(pet.rating),
        trailing: IconButton(
          onPressed: onPressed,
          icon: const Icon(Icons.close),
        ),
      ),
    );
  }
}
