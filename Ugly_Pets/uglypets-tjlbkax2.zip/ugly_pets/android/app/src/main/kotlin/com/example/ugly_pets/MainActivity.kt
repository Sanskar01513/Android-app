package com.example.ugly_pets

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
